package kodlama.io.rentACar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentACarApplicationTests {

	@Test
	void contextLoads() {
	}

}
